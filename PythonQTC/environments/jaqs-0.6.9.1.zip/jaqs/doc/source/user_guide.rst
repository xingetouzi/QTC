用户手册
========

本页面给用户提供了一个简洁清晰的入门指南,涵盖各个功能模块

.. include:: overview.rst

.. include:: data_api.rst

.. include:: data_view.rst

.. include:: research.rst

.. include:: backtest.rst

.. include:: trade_api.rst

.. include:: realtime.rst
