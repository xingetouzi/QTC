jaqs package
============

Subpackages
-----------

.. toctree::

    jaqs.data
    jaqs.research
    jaqs.trade
    jaqs.util

Module contents
---------------

.. automodule:: jaqs
    :members:
    :undoc-members:
    :show-inheritance:
