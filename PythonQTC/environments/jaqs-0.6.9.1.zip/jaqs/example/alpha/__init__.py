# encoding: UTF-8
"""
The example module contains several examples of using py-hft-trade.
"""
