
JAQS
==========================================================

在这里，你将可以获得：

-  使用数据API，轻松获取研究数据
-  根据策略模板，编写自己的量化策略
-  使用回测框架，对策略进行回测和验证

查看代码，请点击\ `GitHub <http://github.com/quantOS-org/jaqs>`__\

Install Guide
-------------

A detailed step-by-step description of installation.

.. toctree::
   :maxdepth: 2

   install


用户手册
-------------

一个简洁清晰的入门指南, 涵盖各个功能模块.

.. toctree::
   :maxdepth: 2

   user_guide


API Refrence
-------------

If you want to know about package hierarchy, specific class / function...

.. toctree::
   :maxdepth: 2

   api_reference


License
-------

Apache 2.0许可协议。版权所有(c)2017 quantOS-org(量化开源会)。
