API说明文档
============

行情数据API文档
---------------
.. toctree::
    :maxdepth: 2

    market_data


参考数据API文档
---------------
.. toctree::
    :maxdepth: 2

    base_data


Other Important APIs
--------------------

.. toctree::
    :maxdepth: 2

    jaqs.data
    jaqs.trade
    jaqs.research
    jaqs.util
