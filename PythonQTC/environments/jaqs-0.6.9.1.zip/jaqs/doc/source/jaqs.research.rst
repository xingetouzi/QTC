jaqs\.research package
======================

Subpackages
-----------

.. toctree::

    jaqs.research.signaldigger

Module contents
---------------

.. automodule:: jaqs.research
    :members:
    :undoc-members:
    :show-inheritance:
