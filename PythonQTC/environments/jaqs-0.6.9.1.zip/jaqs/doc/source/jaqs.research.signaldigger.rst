jaqs\.research\.signaldigger package
====================================

Submodules
----------

jaqs\.research\.signaldigger\.digger module
-------------------------------------------

.. automodule:: jaqs.research.signaldigger.digger
    :members:
    :undoc-members:
    :show-inheritance:

jaqs\.research\.signaldigger\.performance module
------------------------------------------------

.. automodule:: jaqs.research.signaldigger.performance
    :members:
    :undoc-members:
    :show-inheritance:

jaqs\.research\.signaldigger\.plotting module
---------------------------------------------

.. automodule:: jaqs.research.signaldigger.plotting
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: jaqs.research.signaldigger
    :members:
    :undoc-members:
    :show-inheritance:
